<?php

namespace App\Http\Controllers;

use App\Models\Practice;
use App\Models\PracticeTalent;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Silvanix\Wablas\Message;

class TalentController extends Controller
{
    public function dashboard()
    {
        $user = auth()->user();

        $practices_soon = PracticeTalent::where('user_id', $user->id)
            ->whereHas('practice', function ($query) {
                $query->where('session_date', '>=', Carbon::today());
            })
            ->get();

        $practices_history = PracticeTalent::where('user_id', $user->id)
            ->join('practices', 'practice_talent.practice_id', '=', 'practices.id') // Menggabungkan dengan tabel practices
            ->where('practices.session_date', '<', Carbon::today())
            ->orderBy('practices.session_date', 'desc') // Urutkan berdasarkan session_date dari tabel practices
            ->limit(3)
            ->get();

        $lastPotong = PracticeTalent::where('user_id', $user->id)
            ->join('practices', 'practice_talent.practice_id', '=', 'practices.id') // Menggabungkan dengan tabel practices
            ->orderBy('practices.session_date', 'desc') // Mengurutkan berdasarkan session_date dari tabel practices
            ->first();

        return view('talent.home', compact('user', 'practices_soon', 'practices_history', 'lastPotong'));
    }

    public function riwayatPotong()
    {
        $user = auth()->user();

        $practices_history = PracticeTalent::where('user_id', $user->id)
            ->whereHas('practice', function ($query) {
                $query->where('session_date', '<', Carbon::today());
            })
            ->with(['practice' => function ($query) {
                $query->orderBy('session_date', 'desc');
            }])
            ->paginate(10);

        return view('talent.riwayat-potong', compact('practices_history'));
    }

    public function cariJadwal()
    {
        $currentTime = Carbon::now('Asia/Jakarta');
        $today = Carbon::today();

        $user = auth()->user();

        $lastPotong = PracticeTalent::where('user_id', $user->id)
            ->join('practices', 'practice_talent.practice_id', '=', 'practices.id') // Menggabungkan dengan tabel practices
            ->orderBy('practices.session_date', 'desc') // Mengurutkan berdasarkan session_date dari tabel practices
            ->first();

        if ($lastPotong && Carbon::parse($lastPotong->practice->session_date)->diffInDays(Carbon::today()) < 14) {
            return redirect()->route('talent.home');
        }

        // Check if the current time is before or after 14:00 WIB
        if ($currentTime->hour < 14) {
            $dateCondition = '>=';
        } else {
            $dateCondition = '>';
        }

        $practices_available = Practice::where('session_date', $dateCondition, $today)
            ->where('status', 'scheduled')
            ->whereHas('talents', function ($query) {
                $query->havingRaw('COUNT(*) < 3'); // Only practices with less than 3 talents
            }, '<', 3)
            ->withCount('talents') // Count talents for each practice
            ->orderBy('session_date', 'asc')
            ->paginate(6);

        return view('talent.cari-jadwal', compact('practices_available'));
    }


    public function pilihJadwal($id)
    {
        $practice = Practice::findOrFail($id);

        return view('talent.pilih-jadwal', compact('practice'));
    }

    public function storeJadwal(Request $request, string $id)
    {
        $request->validate([
            'session_time' => 'required',
        ]);

        $user = auth()->user();

        // Cek apakah talent sudah memiliki jadwal di waktu yang sama
        $existingPractice = Practice::where(function ($query) use ($user) {
            $query->where('talent_1', $user->id)
                ->orWhere('talent_2', $user->id)
                ->orWhere('talent_3', $user->id);
        })
            ->where('session_date', function ($subquery) use ($id) {
                $subquery->select('session_date')
                    ->from('practices')
                    ->where('id', $id);
            })
            ->exists();

        if ($existingPractice) {
            return back()->withErrors(['session_time' => 'Anda sudah memiliki jadwal potong rambut di waktu yang sama.']);
        }

        // Gunakan transaksi agar aman dari race condition
        return DB::transaction(function () use ($request, $id, $user) {
            $practice = Practice::where('id', $id)->lockForUpdate()->firstOrFail(); // Mengunci data untuk menghindari race condition

            switch ($request->session_time) {
                case 'talent_1':
                    if (is_null($practice->talent_1)) {
                        $practice->talent_1 = $user->id;
                    } else {
                        return back()->withErrors(['session_time' => 'Maaf, sesi baru saja diambil orang lain, mohon pilih sesi yang lainnya.']);
                    }
                    break;
                case 'talent_2':
                    if (is_null($practice->talent_2)) {
                        $practice->talent_2 = $user->id;
                    } else {
                        return back()->withErrors(['session_time' => 'Maaf, sesi baru saja diambil orang lain, mohon pilih sesi yang lainnya.']);
                    }
                    break;
                case 'talent_3':
                    if (is_null($practice->talent_3)) {
                        $practice->talent_3 = $user->id;
                    } else {
                        return back()->withErrors(['session_time' => 'Maaf, sesi baru saja diambil orang lain, mohon pilih sesi yang lainnya.']);
                    }
                    break;
                default:
                    return back()->with('error', 'Sesi tidak valid');
            }

            $practice->save();

            // Simpan di tabel pivot (jika ada relasi Many-to-Many)
            $sessionNumber = $request->session_time === 'talent_1' ? 1 : ($request->session_time === 'talent_2' ? 2 : 3);
            $practice->talents()->syncWithoutDetaching([$user->id => ['session_time' => $sessionNumber]]);

            // Kirim pesan WhatsApp ke user
            $phone = $user->phone_number;
            $dayOfWeek = Carbon::parse($practice->session_date)->locale('id')->isoFormat('dddd');
            $formattedDate = Carbon::parse($practice->session_date)->format('d/m/Y');

            function getWaktuSesi($sessionTime, $sessionNumber)
            {
                $waktu = '';

                if ($sessionTime == 'siang') {
                    switch ($sessionNumber) {
                        case 1:
                            $waktu = '14.00';
                            break;
                        case 2:
                            $waktu = '15.00';
                            break;
                        case 3:
                            $waktu = '16.00';
                            break;
                    }
                } elseif ($sessionTime == 'malam') {
                    switch ($sessionNumber) {
                        case 1:
                            $waktu = '18.30';
                            break;
                        case 2:
                            $waktu = '19.30';
                            break;
                        case 3:
                            $waktu = '20.30';
                            break;
                    }
                }

                return $waktu;
            }

            $message = 'Halo, Kak ' . ucwords($user->name) . "\n\n";
            $message .= "Terima kasih sudah memilih jadwal potong rambut.\n\n";
            $message .= "Berikut merupakan rincian jadwal yang telah dibuat:\n";
            $message .= 'Hari : ' . $dayOfWeek . "\n";
            $message .= 'Tanggal : ' . $formattedDate . "\n";

            $waktu = getWaktuSesi($practice->session_time, $sessionNumber);
            $message .= 'Waktu : ' . $waktu . "\n";

            $message .= "\nHarap untuk hadir 10 Menit Sebelum Jadwal Potong sesuai jadwal yang sudah dipilih. Terima kasih!";

            // Kirim pesan WhatsApp
            $send = new Message();
            $send_text = $send->single_text($phone, $message);

            return redirect()->route('talent.home')->with('success', 'Jadwal berhasil dibuat 😎');
        });
    }
}
