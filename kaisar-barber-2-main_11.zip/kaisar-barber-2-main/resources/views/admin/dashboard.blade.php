@extends('layouts.user_type.admin')

@section('content')

<div class="row">
  <div class="col-md-3 mb-xl-0 mb-4">
    <div class="card">
      <div class="card-body p-3">
        <div class="row">
          <div class="col-8">
            <div class="numbers">
              <p class="text-sm mb-0 text-red text-capitalize font-weight-bold">Total Semua Siswa</p>
              <h3 class="font-weight-bolder mb-0">
                {{ $totalSiswaKeseluruhan }}
              </h3>
            </div>
          </div>
          <div class="col-4 text-end">
            <div class="icon icon-shape bg-gradient-primary shadow text-center border-radius-md">
              <i class="fas fa-users text-lg opacity-10" aria-hidden="true"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3 mb-xl-0 mb-4">
    <div class="card">
      <div class="card-body p-3">
        <div class="row">
          <div class="col-8">
            <div class="numbers">
              <p class="text-sm mb-0 text-red text-capitalize font-weight-bold">Siswa Baru Bulan Ini</p>
              <h3 class="font-weight-bolder mb-0">
                {{ $totalSiswaBulanIni }}
              </h3>
            </div>
          </div>
          <div class="col-4 text-end">
            <div class="icon icon-shape bg-gradient-primary shadow text-center border-radius-md">
              <i class="fas fa-graduation-cap text-lg opacity-10" aria-hidden="true"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<h6 class="mt-4">Total Kursus</h6>
<div class="row mt-2">
  @foreach($totalSiswaPerKelas as $className => $totalSiswa)
  <div class="col-xl-2 col-sm-4 mb-xl-0 mb-4">
    <div class="card">
      <div class="card-body p-3">
        <div class="row">
          <div class="col-8">
            <div class="numbers">
              <p class="text-sm text-red mb-0 text-capitalize font-weight-bold">{{ $className }}</p>
              <h5 class="font-weight-bolder mb-0">
                {{ $totalSiswa }} Siswa
              </h5>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  @endforeach
</div>

<div class="row mt-4">
  <div class="col-md-6">
    <h6 class="mb-2">Jadwal Praktek Hari Ini</h6>
    <div class="card mb-3">
      <div class="card-header pb-0">
        <div class="d-flex flex-column justify-content-between">
          <ul class="list-group">
            @foreach($today_practices as $practice)
            <li class="list-group-item my-2 rounded-3 p-3 border-1 border-red shadow" style="background: linear-gradient(91deg, #FFE5F3 15.23%, #F2E0FF 73.91%);">
              <div class="row">
                <div class="col-md-6">
                  <div class="row">
                    <div class="col-4">
                      <img src="{{ ($practice->course->user->photo_path ? asset('storage/' . $practice->course->user->photo_path) : asset('assets/img/user-1.jpg'))}}"
                        class="w-100 rounded-3 border border-white border-2 shadow"
                        style="width: 100%; height: auto; aspect-ratio: 1 / 1; object-fit: cover;"
                        alt="">
                    </div>
                    <div class="col-8 px-0">
                      <h6 class="text-red fw-black mb-0 lh-sm">{{ucwords($practice->course->user->name)}}</h6>
                      <span class="text-dark text-sm">{{ucfirst($practice->session_time)}} ({{$practice->session_time === 'siang' ? '14:00 - 17.00' : '18:30 - 21:00'}})</span>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <h6 class="text-sm text-secondary mb-1">Talent:</h6>
                  @if($practice->talents->isEmpty())
                  <div><span class="badge badge-sm bg-gradient-danger">Belum ada talent</span></div>
                  @else
                  <div>
                    @foreach($practice->talents as $talent)
                    <span class="badge badge-sm bg-gradient-success mb-1">
                      {{ $talent->name }} ({{ 'Sesi ' . $talent->pivot->session_time }})
                    </span>
                    @endforeach
                  </div>
                  @endif
                </div>
              </div>
            </li>
            @endforeach

            @if($today_practices->isEmpty())
            <li class="list-group-item border-0 d-flex align-items-center px-0 mb-2">
              <div class="bg-red-100 alert border border-red d-flex flex-column align-items-center justify-content-center w-100 text-red" role="alert">
                <img src="{{ asset('assets/img/icons/Warning.png') }}" alt="">
                <span>Tidak ada praktek hari ini</span>
              </div>
            </li>
            @endif
          </ul>
        </div>
      </div>
      <div class="card-body pb-2">

      </div>
    </div>
  </div>
  <div class="col-md-6">
    <h6 class="mb-2">Jadwal Praktek Hari Ini</h6>
    <div class="card mb-3">
      <div class="card-header pb-0">
        <div class="d-flex flex-column justify-content-between">
          <ul class="list-group">
            @foreach($tomorrow_practices as $practice)
            <li class="list-group-item my-2 rounded-3 p-3 border-1 border-red shadow" style="background: linear-gradient(91deg, #FFE5F3 15.23%, #F2E0FF 73.91%);">
              <div class="row">
                <div class="col-md-6">
                  <div class="row">
                    <div class="col-4">
                      <img src="{{ ($practice->course->user->photo_path ? asset('storage/' . $practice->course->user->photo_path) : asset('assets/img/user-1.jpg'))}}"
                        class="w-100 rounded-3 border border-white border-2 shadow"
                        style="width: 100%; height: auto; aspect-ratio: 1 / 1; object-fit: cover;"
                        alt="">
                    </div>
                    <div class="col-8 px-0">
                      <h6 class="text-red fw-black mb-0 lh-sm">{{ucwords($practice->course->user->name)}}</h6>
                      <span class="text-dark text-sm">{{ucfirst($practice->session_time)}} ({{$practice->session_time === 'siang' ? '14:00 - 17.00' : '18:30 - 21:00'}})</span>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <h6 class="text-sm text-secondary mb-1">Talent:</h6>
                  @if($practice->talents->isEmpty())
                  <div><span class="badge badge-sm bg-gradient-danger">Belum ada talent</span></div>
                  @else
                  <div>
                    @foreach($practice->talents as $talent)
                    <span class="badge badge-sm bg-gradient-success mb-1">
                      {{ $talent->name }} ({{ 'Sesi ' . $talent->pivot->session_time }})
                    </span>
                    @endforeach
                  </div>
                  @endif
                </div>
              </div>
            </li>
            @endforeach

            @if($tomorrow_practices->isEmpty())
            <li class="list-group-item border-0 d-flex align-items-center px-0 mb-2">
              <div class="bg-red-100 alert border border-red d-flex flex-column align-items-center justify-content-center w-100 text-red" role="alert">
                <img src="{{ asset('assets/img/icons/Warning.png') }}" alt="">
                <span>Tidak ada praktek Besok</span>
              </div>
            </li>
            @endif
          </ul>
        </div>
      </div>
      <div class="card-body pb-2">

      </div>
    </div>
  </div>
</div>
<div class="row mt-4">
  <div class="col-md-6 mb-xl-0 mb-4">
    <div class="card">
      <div class="card-body p-3">
        <div class="row">
          <div class="col-8">
            <div class="numbers">
              <p class="text-sm mb-0 text-red text-capitalize font-weight-bold">Total Talent Aktif</p>
              <h3 class="font-weight-bolder mb-0">
                {{ $totalTalentAktif }}
              </h3>
            </div>
          </div>
          <div class="col-4 text-end">
            <div class="icon icon-shape bg-gradient-primary shadow text-center border-radius-md">
              <i class="fas fa-users text-lg opacity-10" aria-hidden="true"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

@endsection
@push('dashboard')
<script>
  window.onload = function() {
    var ctx = document.getElementById("chart-bars").getContext("2d");

    new Chart(ctx, {
      type: "bar",
      data: {
        labels: ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        datasets: [{
          label: "Sales",
          tension: 0.4,
          borderWidth: 0,
          borderRadius: 4,
          borderSkipped: false,
          backgroundColor: "#fff",
          data: [450, 200, 100, 220, 500, 100, 400, 230, 500],
          maxBarThickness: 6
        }, ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          }
        },
        interaction: {
          intersect: false,
          mode: 'index',
        },
        scales: {
          y: {
            grid: {
              drawBorder: false,
              display: false,
              drawOnChartArea: false,
              drawTicks: false,
            },
            ticks: {
              suggestedMin: 0,
              suggestedMax: 500,
              beginAtZero: true,
              padding: 15,
              font: {
                size: 14,
                family: "Open Sans",
                style: 'normal',
                lineHeight: 2
              },
              color: "#fff"
            },
          },
          x: {
            grid: {
              drawBorder: false,
              display: false,
              drawOnChartArea: false,
              drawTicks: false
            },
            ticks: {
              display: false
            },
          },
        },
      },
    });


    var ctx2 = document.getElementById("chart-line").getContext("2d");

    var gradientStroke1 = ctx2.createLinearGradient(0, 230, 0, 50);

    gradientStroke1.addColorStop(1, 'rgba(203,12,159,0.2)');
    gradientStroke1.addColorStop(0.2, 'rgba(72,72,176,0.0)');
    gradientStroke1.addColorStop(0, 'rgba(203,12,159,0)'); //purple colors

    var gradientStroke2 = ctx2.createLinearGradient(0, 230, 0, 50);

    gradientStroke2.addColorStop(1, 'rgba(20,23,39,0.2)');
    gradientStroke2.addColorStop(0.2, 'rgba(72,72,176,0.0)');
    gradientStroke2.addColorStop(0, 'rgba(20,23,39,0)'); //purple colors

    new Chart(ctx2, {
      type: "line",
      data: {
        labels: ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        datasets: [{
            label: "Mobile apps",
            tension: 0.4,
            borderWidth: 0,
            pointRadius: 0,
            borderColor: "#cb0c9f",
            borderWidth: 3,
            backgroundColor: gradientStroke1,
            fill: true,
            data: [50, 40, 300, 220, 500, 250, 400, 230, 500],
            maxBarThickness: 6

          },
          {
            label: "Websites",
            tension: 0.4,
            borderWidth: 0,
            pointRadius: 0,
            borderColor: "#3A416F",
            borderWidth: 3,
            backgroundColor: gradientStroke2,
            fill: true,
            data: [30, 90, 40, 140, 290, 290, 340, 230, 400],
            maxBarThickness: 6
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          }
        },
        interaction: {
          intersect: false,
          mode: 'index',
        },
        scales: {
          y: {
            grid: {
              drawBorder: false,
              display: true,
              drawOnChartArea: true,
              drawTicks: false,
              borderDash: [5, 5]
            },
            ticks: {
              display: true,
              padding: 10,
              color: '#b2b9bf',
              font: {
                size: 11,
                family: "Open Sans",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
          x: {
            grid: {
              drawBorder: false,
              display: false,
              drawOnChartArea: false,
              drawTicks: false,
              borderDash: [5, 5]
            },
            ticks: {
              display: true,
              color: '#b2b9bf',
              padding: 20,
              font: {
                size: 11,
                family: "Open Sans",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
        },
      },
    });
  }
</script>
@endpush