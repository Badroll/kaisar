<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('ms_holidays', function (Blueprint $table) {
            $table->boolean('teori_closed')->default(true);
            $table->boolean('praktek1_closed')->default(true);
            $table->boolean('praktek2_closed')->default(true);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('ms_holidays', function (Blueprint $table) {
            $table->dropColumn(['teori_closed', 'praktek1_closed', 'praktek2_closed']);
        });
    }
};
