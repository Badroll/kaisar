<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Holiday;
use App\Models\Practice;
use App\Models\Teori;
use Illuminate\Http\Request;

class HariBesarController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('admin.hari-besar.index');
    }

    public function getData()
    {
        $holidays = Holiday::all();

        return datatables()->of($holidays)
            ->addColumn('teori_closed', function ($holiday) {
                if ($holiday->teori_closed == true) {
                    return '<span class="badge badge-sm bg-gradient-warning">Libur</span>';
                } else {
                    return '<span class="badge badge-sm bg-gradient-success">Masuk</span>';
                }
            })
            ->addColumn('praktek1_closed', function ($holiday) {
                if ($holiday->praktek1_closed == true) {
                    return '<span class="badge badge-sm bg-gradient-warning">Libur</span>';
                } else {
                    return '<span class="badge badge-sm bg-gradient-success">Masuk</span>';
                }
            })
            ->addColumn('praktek2_closed', function ($holiday) {
                if ($holiday->praktek2_closed == true) {
                    return '<span class="badge badge-sm bg-gradient-warning">Libur</span>';
                } else {
                    return '<span class="badge badge-sm bg-gradient-success">Masuk</span>';
                }
            })
            ->addColumn('action', function ($holiday) {
                $editRoute = route('hari-besar.edit', $holiday->id);
                $deleteRoute = route('hari-besar.destroy', $holiday->id);
                return '<a href="' . $editRoute . '" class="btn btn-warning" data-bs-toggle="tooltip" data-bs-original-title="Edit Kelas">
                        <i class="fas fa-user-edit text-white"></i>
                    </a>
                    <form action="' . $deleteRoute . '" method="post" class="d-inline">
                          ' . csrf_field() . '
                          ' . method_field('delete') . '
                          <button class="btn btn-danger" data-toggle="tooltip" data-original-title="Delete Kelas" onclick="return confirm(\'Apakah kamu yakin ingin menghapus hari besar ini?\')">
                            <i class="cursor-pointer fas fa-trash text-white"></i>
                          </button>
                    </form>';
            })
            ->rawColumns(['action', 'teori_closed', 'praktek1_closed', 'praktek2_closed'])
            ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admin.hari-besar.create');
    }

    /**
     * Store a newly created resour
     * ce in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'date' => 'required|date',
        ]);

        $validatedData['teori_closed'] = $request->has('teori_closed') ? true : false;
        $validatedData['praktek1_closed'] = $request->has('praktek1_closed') ? true : false;
        $validatedData['praktek2_closed'] = $request->has('praktek2_closed') ? true : false;

        $hasPractice1 = Practice::where('session_date', $request->date)->where('session_time', 'siang')->exists();
        $hasPractice2 = Practice::where('session_date', $request->date)->where('session_time', 'malam')->exists();
        $hasTeori = Teori::where('session_date', $request->date)->exists();

        if ($validatedData['praktek1_closed'] && $hasPractice1) {
            return redirect()->back()->withErrors(['message' => 'Terdapat praktek sesi siang hari terjadwal pada tanggal tersebut, mohon pindah terlebih dahulu.'])->withInput();
        }

        if ($validatedData['praktek2_closed'] && $hasPractice2) {
            return redirect()->back()->withErrors(['message' => 'Terdapat praktek sesi malam hari terjadwal pada tanggal tersebut, mohon pindah terlebih dahulu.'])->withInput();
        }

        if ($validatedData['teori_closed'] && $hasTeori) {
            return redirect()->back()->withErrors(['message' => 'Terdapat sesi teori terjadwal pada tanggal tersebut, mohon pindah terlebih dahulu.'])->withInput();
        }

        $holiday = Holiday::create($validatedData);

        return redirect()->route('hari-besar.index')->with('success', 'Hari Besar berhasil ditambahkan.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $holiday = Holiday::findOrFail($id);
        return view('admin.hari-besar.edit', compact('holiday'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $holiday = Holiday::findOrFail($id);

        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'date' => 'required|date',
        ]);

        $validatedData['teori_closed'] = $request->has('teori_closed') ? true : false;
        $validatedData['praktek1_closed'] = $request->has('praktek1_closed') ? true : false;
        $validatedData['praktek2_closed'] = $request->has('praktek2_closed') ? true : false;

        $hasPractice1 = Practice::where('session_date', $request->date)
            ->where('session_time', 'siang')
            ->exists();
        $hasPractice2 = Practice::where('session_date', $request->date)
            ->where('session_time', 'malam')
            ->exists();
        $hasTeori = Teori::where('session_date', $request->date)->exists();

        if ($validatedData['praktek1_closed'] && $hasPractice1) {
            return redirect()->back()
                ->withErrors(['message' => 'Terdapat praktek sesi siang hari terjadwal pada tanggal tersebut, mohon pindah terlebih dahulu.'])
                ->withInput();
        }

        if ($validatedData['praktek2_closed'] && $hasPractice2) {
            return redirect()->back()
                ->withErrors(['message' => 'Terdapat praktek sesi malam hari terjadwal pada tanggal tersebut, mohon pindah terlebih dahulu.'])
                ->withInput();
        }

        if ($validatedData['teori_closed'] && $hasTeori) {
            return redirect()->back()
                ->withErrors(['message' => 'Terdapat sesi teori terjadwal pada tanggal tersebut, mohon pindah terlebih dahulu.'])
                ->withInput();
        }

        $holiday->name = $validatedData['name'];
        $holiday->date = $validatedData['date'];
        $holiday->teori_closed = $validatedData['teori_closed'];
        $holiday->praktek1_closed = $validatedData['praktek1_closed'];
        $holiday->praktek2_closed = $validatedData['praktek2_closed'];
        $holiday->save();

        return redirect()->route('hari-besar.index')->with('success', 'Hari Besar berhasil diperbarui.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $holiday = Holiday::findOrFail($id);

        $holiday->delete();

        return redirect()->route('hari-besar.index')->with('success', 'Hari Besar berhasil dihapus.');
    }
}
